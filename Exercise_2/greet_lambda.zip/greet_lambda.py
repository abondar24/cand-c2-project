import os

def lambda_handler(event, context):
    return "Greet from Lambda!"
